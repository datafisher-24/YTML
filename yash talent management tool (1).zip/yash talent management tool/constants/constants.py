
HOST = "localhost"
USER = "root"
PASSWORD = "root"
DB_NAME = "python_training_management_database"